// Temas cubiertos: API Streams, Clase Optional

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

public class Ejemplo3_StreamsYOptional {

    // Record para los ejemplos con objetos reales
    record Producto(String nombre, String categoria, double precio) {}

    public static void main(String[] args) {

        // ── STREAMS ───────────────────────────────────────────────────────
        // Un Stream no modifica la colección original, solo la procesa.
        // Las operaciones se encadenan: filter → map → collect → etc.

        System.out.println("=== Streams ===");
        List<Integer> numeros = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        // Filtra los pares y suma todos
        int sumaPares = numeros.stream()
                               .filter(n -> n % 2 == 0)
                               .mapToInt(Integer::intValue)
                               .sum();
        System.out.println("Suma de pares: " + sumaPares); // 30

        // Toma los primeros 5 números, calcula su cuadrado y los recolecta en una lista
        List<String> cuadrados = numeros.stream()
                                        .filter(n -> n <= 5)
                                        .map(n -> n + "² = " + (n * n))
                                        .collect(Collectors.toList());
        cuadrados.forEach(System.out::println);

        // Ejemplo con objetos — filtra por categoría y ordena por precio
        List<Producto> productos = Arrays.asList(
            new Producto("Laptop",     "Electrónica", 1500.0),
            new Producto("Teclado",    "Electrónica",   80.0),
            new Producto("Silla",      "Muebles",       300.0),
            new Producto("Escritorio", "Muebles",       450.0),
            new Producto("Mouse",      "Electrónica",    25.0)
        );

        System.out.println("\nElectrónica ordenada por precio:");
        productos.stream()
                 .filter(p -> p.categoria().equals("Electrónica"))
                 .sorted((a, b) -> Double.compare(a.precio(), b.precio()))
                 .forEach(p -> System.out.printf("  %s: $%.2f%n", p.nombre(), p.precio()));

        // El promedio puede no existir si la lista está vacía — por eso devuelve OptionalDouble
        OptionalDouble promedio = productos.stream()
                                           .mapToDouble(Producto::precio)
                                           .average();
        System.out.printf("Precio promedio: $%.2f%n", promedio.orElse(0));


        // ── OPTIONAL ─────────────────────────────────────────────────────
        // Optional es un contenedor: puede tener un valor o estar vacío.
        // Sirve para evitar devolver null y lidiar con NullPointerException.

        System.out.println("\n=== Optional ===");

        Optional<String> conValor = Optional.of("Hola Java");
        conValor.ifPresent(v -> System.out.println("Valor: " + v));
        System.out.println("En mayúsculas: " + conValor.map(String::toUpperCase).orElse("vacío"));

        Optional<String> vacio = Optional.empty();

        // orElse siempre devuelve el valor por defecto si el Optional está vacío
        String resultado = vacio.orElse("Valor por defecto");
        System.out.println("Optional vacío: " + resultado);

        // orElseGet es lazy: el Supplier solo se ejecuta si realmente hace falta
        String lazy = vacio.orElseGet(() -> "Generado lazily");
        System.out.println("orElseGet: " + lazy);

        // Buscar el producto más barato de la lista
        Optional<Producto> masBarato = productos.stream()
                                                .min((a, b) -> Double.compare(a.precio(), b.precio()));
        masBarato.ifPresent(p -> System.out.println("Más barato: " + p.nombre() + " $" + p.precio()));
    }
}
