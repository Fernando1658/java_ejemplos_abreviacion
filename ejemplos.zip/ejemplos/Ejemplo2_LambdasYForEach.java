// Temas cubiertos: For-each, Expresiones Lambda, Referencias a métodos (::)

import java.util.Arrays;
import java.util.List;

public class Ejemplo2_LambdasYForEach {

    // Interfaz funcional propia — tiene un solo método abstracto
    @FunctionalInterface
    interface Operacion {
        int aplicar(int a, int b);
    }

    public static void main(String[] args) {

        // ── FOR-EACH ──────────────────────────────────────────────────────
        // Recorre cada elemento sin necesidad de manejar índices.
        // Más limpio que el for clásico cuando solo necesitas leer los elementos.

        String[] colores = {"rojo", "verde", "azul"};
        System.out.println("=== For-each ===");
        for (String color : colores) {
            System.out.println("Color: " + color);
        }


        // ── LAMBDAS ───────────────────────────────────────────────────────
        // Una lambda es una función sin nombre. Se usa cuando se necesita pasar
        // "comportamiento" como parámetro, como al ordenar o filtrar.

        System.out.println("\n=== Lambdas ===");
        List<String> nombres = Arrays.asList("Carlos", "Ana", "Beatriz", "David");

        // Ordenar con lambda — mucho más corto que una clase anónima
        nombres.sort((a, b) -> a.compareTo(b));
        System.out.println("Ordenados: " + nombres);

        // Lambda asignada a una interfaz funcional
        Operacion suma           = (a, b) -> a + b;
        Operacion multiplicacion = (a, b) -> a * b;
        System.out.println("Suma 3+4 = "     + suma.aplicar(3, 4));
        System.out.println("Producto 3x4 = " + multiplicacion.aplicar(3, 4));

        nombres.forEach(nombre -> System.out.println("Hola, " + nombre));


        // ── REFERENCIAS A MÉTODOS ─────────────────────────────────────────
        // Cuando una lambda solo llama a un método existente, se puede reemplazar
        // directamente con NombreClase::nombreMetodo

        System.out.println("\n=== Referencias a Métodos ===");

        List<String> palabras = Arrays.asList("hola", "mundo", "java");
        palabras.stream()
                .map(String::toUpperCase)      // equivalente a: s -> s.toUpperCase()
                .forEach(System.out::println); // equivalente a: s -> System.out.println(s)

        List<Integer> nums = Arrays.asList(3, 1, 4, 1, 5, 9, 2, 6);
        nums.stream()
            .sorted()
            .forEach(System.out::println);
    }
}
