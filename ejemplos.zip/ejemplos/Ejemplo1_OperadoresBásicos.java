// Temas cubiertos: Operador Ternario (?:), Operadores Compuestos (+=, -=, *=, /=, %=),
// Incremento y Decremento (++, --)

public class Ejemplo1_OperadoresBásicos {

    public static void main(String[] args) {

        // ── OPERADOR TERNARIO ──────────────────────────────────────────────
        // Reemplaza un if-else simple en una sola línea.
        // Formato: condicion ? valor_si_true : valor_si_false

        int edad = 20;
        String estado = edad >= 18 ? "Mayor de edad" : "Menor de edad";
        System.out.println("Estado: " + estado);

        // También se puede anidar, aunque hay que tener cuidado de no exagerar
        int nota = 75;
        String calificacion = nota >= 90 ? "Excelente"
                            : nota >= 70 ? "Aprobado"
                            : "Reprobado";
        System.out.println("Calificación: " + calificacion);


        // ── OPERADORES DE ASIGNACIÓN COMPUESTA ────────────────────────────
        // En lugar de escribir: total = total + 15
        // se escribe simplemente: total += 15

        double precio = 100.0;

        precio += 15;    // agrega el impuesto → 115.0
        System.out.println("Con impuesto: " + precio);

        precio *= 0.9;   // aplica 10% de descuento
        System.out.println("Con descuento: " + precio);

        precio -= 5;     // descuenta el costo de envío
        System.out.println("Precio final: " + precio);

        int numero = 17;
        numero %= 5;     // el residuo de 17 / 5 es 2
        System.out.println("17 % 5 = " + numero);


        // ── INCREMENTO Y DECREMENTO ───────────────────────────────────────
        // ++ suma 1, -- resta 1.
        // La diferencia entre prefijo y sufijo importa cuando se usa dentro de una expresión.

        int contador = 0;
        contador++;
        System.out.println("Después de ++: " + contador); // 1

        int a = 5;
        int b = a++;  // b toma el valor actual de a (5), luego a se vuelve 6
        int c = ++a;  // a se vuelve 7 primero, luego c toma ese valor
        System.out.println("a=" + a + ", b=" + b + ", c=" + c); // a=7, b=5, c=7
    }
}
