// Temas cubiertos: List.of(), Set.of(), Map.of(), Operador Diamond (<>),
// forEach(), removeIf(), Collectors.groupingBy(), IntStream.range()

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Ejemplo5_Colecciones {

    record Estudiante(String nombre, String carrera, int nota) {}

    public static void main(String[] args) {

        // ── COLECCIONES INMUTABLES ────────────────────────────────────────
        // List.of(), Set.of() y Map.of() crean colecciones que no se pueden modificar.
        // Si intentas hacer add() o remove(), lanza UnsupportedOperationException.

        System.out.println("=== List.of() / Set.of() / Map.of() ===");

        List<String> diasHabiles = List.of("Lunes", "Martes", "Miércoles", "Jueves", "Viernes");
        System.out.println("Días hábiles: " + diasHabiles);

        // Set no garantiza orden y no permite duplicados
        Set<String> lenguajes = Set.of("Java", "Python", "Kotlin", "Scala");
        System.out.println("Lenguajes: " + lenguajes);

        Map<String, String> capitales = Map.of(
            "Colombia",  "Bogotá",
            "México",    "Ciudad de México",
            "Argentina", "Buenos Aires",
            "Chile",     "Santiago"
        );
        capitales.forEach((pais, capital) ->
            System.out.println(pais + " → " + capital));


        // ── OPERADOR DIAMOND (<>) ─────────────────────────────────────────
        // El compilador infiere los tipos genéricos de la declaración.
        // Sin diamond (Java antiguo): new HashMap<String, List<Integer>>()
        // Con diamond:                new HashMap<>()

        System.out.println("\n=== Operador Diamond ===");
        Map<String, List<Integer>> calificaciones = new HashMap<>();
        calificaciones.put("Ana", new ArrayList<>());
        calificaciones.get("Ana").add(90);
        calificaciones.get("Ana").add(85);
        System.out.println("Calificaciones Ana: " + calificaciones.get("Ana"));


        // ── forEach() ────────────────────────────────────────────────────
        // Itera con estilo funcional. Se puede combinar con filter para mayor control.

        System.out.println("\n=== forEach() ===");
        List<Integer> numeros = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
        System.out.print("Pares: ");
        numeros.stream()
               .filter(n -> n % 2 == 0)
               .forEach(n -> System.out.print(n + " "));
        System.out.println();


        // ── removeIf() ───────────────────────────────────────────────────
        // Elimina todos los elementos que cumplan la condición dada.
        // Mucho más limpio que iterar con un iterador manualmente.

        System.out.println("\n=== removeIf() ===");
        List<String> nombres = new ArrayList<>(
            Arrays.asList("Ana", "  ", "Luis", "", "María", "  Carlos  ", "")
        );
        System.out.println("Antes: " + nombres);
        nombres.removeIf(String::isBlank); // elimina los vacíos y los que solo tienen espacios
        System.out.println("Después: " + nombres);

        List<Integer> lista = new ArrayList<>(Arrays.asList(1, 8, 3, 7, 2, 9, 4, 6));
        lista.removeIf(n -> n < 5);
        System.out.println("Sin menores a 5: " + lista);


        // ── groupingBy() ─────────────────────────────────────────────────
        // Agrupa los elementos de un stream por una clave y devuelve un Map.
        // Reemplaza bucles manuales de agrupación.

        System.out.println("\n=== groupingBy() ===");
        List<Estudiante> estudiantes = Arrays.asList(
            new Estudiante("Ana",    "Ingeniería", 90),
            new Estudiante("Luis",   "Medicina",   85),
            new Estudiante("María",  "Ingeniería", 78),
            new Estudiante("Carlos", "Derecho",    92),
            new Estudiante("Sofía",  "Medicina",   88),
            new Estudiante("Pedro",  "Derecho",    75)
        );

        Map<String, List<Estudiante>> porCarrera = estudiantes.stream()
            .collect(Collectors.groupingBy(Estudiante::carrera));

        porCarrera.forEach((carrera, alumnos) -> {
            System.out.println(carrera + ":");
            alumnos.forEach(e -> System.out.println("  " + e.nombre() + " - " + e.nota()));
        });

        // También se puede calcular el promedio por grupo directamente
        System.out.println("\nPromedio por carrera:");
        estudiantes.stream()
            .collect(Collectors.groupingBy(
                Estudiante::carrera,
                Collectors.averagingInt(Estudiante::nota)
            ))
            .forEach((c, avg) -> System.out.printf("  %s: %.1f%n", c, avg));


        // ── IntStream.range() CON ÍNDICE ──────────────────────────────────
        // El for-each no da el índice. IntStream.range() lo resuelve en estilo funcional.
        // Genera los números del rango [inicio, fin) y los usa como índices.

        System.out.println("\n=== IntStream.range() con índice ===");
        List<String> items = List.of("Manzana", "Naranja", "Pera", "Uva");
        IntStream.range(0, items.size())
                 .forEach(i -> System.out.println((i + 1) + ". " + items.get(i)));
    }
}
