// Temas cubiertos: var, Switch Expression, Text Blocks, Records, Pattern Matching
// Requiere Java 16 o superior

import java.util.List;
import java.util.Map;

public class Ejemplo4_CaracterísticasModernas {

    // ── RECORDS ───────────────────────────────────────────────────────────
    // El compilador genera automáticamente: constructor, getters, equals, hashCode y toString.
    // Son inmutables por diseño.

    record Empleado(String nombre, String departamento, double salario) {}

    record Punto(double x, double y) {
        // Constructor compacto — ideal para validaciones
        Punto {
            if (x < 0 || y < 0) throw new IllegalArgumentException("Las coordenadas deben ser positivas");
        }

        double distanciaAlOrigen() {
            return Math.sqrt(x * x + y * y);
        }
    }


    public static void main(String[] args) {

        // ── VAR ───────────────────────────────────────────────────────────
        // El compilador deduce el tipo a partir del valor asignado.
        // El tipo sigue siendo estático — no es como var de JavaScript.

        System.out.println("=== var ===");
        var mensaje = "Hola desde var";          // el compilador sabe que es String
        var numero  = 42;                         // int
        var lista   = List.of("a", "b", "c");     // List<String>
        var mapa    = Map.of("uno", 1, "dos", 2); // Map<String, Integer>

        System.out.println(mensaje);
        System.out.println("Número: " + numero);
        for (var item : lista) {
            System.out.println("Item: " + item);
        }


        // ── SWITCH EXPRESSION ─────────────────────────────────────────────
        // Con la nueva sintaxis de flecha (->) no hace falta break.
        // Además se puede usar como expresión y asignar su resultado directamente.

        System.out.println("\n=== Switch Expression ===");
        int[] diasDePrueba = {1, 3, 5, 6, 7};
        for (int dia : diasDePrueba) {
            String tipo = switch (dia) {
                case 1, 2, 3, 4, 5 -> "Día laboral";
                case 6, 7           -> "Fin de semana";
                default             -> "Inválido";
            };
            System.out.println("Día " + dia + ": " + tipo);
        }

        // yield se usa cuando el caso tiene más de una línea
        int puntos = 85;
        String grado = switch (puntos / 10) {
            case 10, 9 -> "A";
            case 8     -> "B";
            case 7     -> {
                System.out.println("  (nota: cerca de notable)");
                yield "C";
            }
            default -> "D";
        };
        System.out.println("Grado para " + puntos + " puntos: " + grado);


        // ── TEXT BLOCKS ───────────────────────────────────────────────────
        // Strings multilínea con """ — no más \n ni concatenación con +.
        // Muy útil para JSON, SQL, HTML embebido en el código.

        System.out.println("\n=== Text Blocks ===");
        String json = """
                {
                  "nombre": "Juan Pérez",
                  "edad": 30,
                  "activo": true
                }
                """;
        System.out.println(json);

        String sql = """
                SELECT nombre, salario
                FROM empleados
                WHERE departamento = 'IT'
                ORDER BY salario DESC
                """;
        System.out.println("Consulta SQL:\n" + sql);


        // ── USO DE RECORDS ────────────────────────────────────────────────
        System.out.println("=== Records ===");
        var emp = new Empleado("María García", "IT", 55000.0);
        System.out.println(emp);                          // toString automático
        System.out.println("Nombre: "  + emp.nombre());   // getter automático
        System.out.println("Salario: $" + emp.salario());

        var p = new Punto(3.0, 4.0);
        System.out.printf("Distancia al origen: %.1f%n", p.distanciaAlOrigen()); // 5.0


        // ── PATTERN MATCHING CON instanceof ──────────────────────────────
        // Antes: if (obj instanceof String) { String s = (String) obj; ... }
        // Ahora: if (obj instanceof String s) { ... }  ← sin el cast manual

        System.out.println("\n=== Pattern Matching ===");
        Object[] objetos = {"Hola", 42, 3.14, true, new Empleado("Luis", "RRHH", 40000)};

        for (Object obj : objetos) {
            if (obj instanceof String s) {
                System.out.println("String de longitud " + s.length() + ": " + s);
            } else if (obj instanceof Integer i) {
                System.out.println("Entero al cuadrado: " + (i * i));
            } else if (obj instanceof Double d) {
                System.out.printf("Double redondeado: %.0f%n", d);
            } else if (obj instanceof Empleado e) {
                System.out.println("Empleado: " + e.nombre() + " en " + e.departamento());
            } else {
                System.out.println("Otro tipo: " + obj);
            }
        }
    }
}
